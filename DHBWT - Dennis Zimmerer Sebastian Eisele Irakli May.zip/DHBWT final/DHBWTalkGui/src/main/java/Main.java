import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.*;
import java.util.List;
import java.util.Timer;

import com.google.gson.JsonObject;
import main_frame.PopUp;
import main_frame.RegistrationFrame;
import utility.Certification;
import utility.RequestFunc;
import utility.ResourceFunc;
import user.User;
import main_frame.FrameUI;

import javax.swing.*;

import com.google.gson.Gson;

public class Main {

	private static final Certification certification = Certification.getInstance();
	public static ResourceFunc resourceFunc = ResourceFunc.getInstance();
	private static User appUser = null;

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				File cert_dir = new File(new JFileChooser().getFileSystemView().getDefaultDirectory().toString() +
						File.separatorChar + "dhbwtalk" + File.separatorChar);
				// Get directory of certificate.txt independent of OS

				if(!cert_dir.exists()) {
					cert_dir.mkdirs();
				}

				FrameUI frame = new FrameUI();
				//New user (registration)

				if(!certification.checkCertificate(false))
				{
					frame.setVisible(false);
					firstRegistration(frame);
					//User gets set inside @firstRegistration()
					//Application user gets changed inside @firstRegistration()
				}
				//Existing user
				else
				{
					boolean password_valid = certification.checkCertificate(true);
					//frame.setVisible(true);
					//close if password invalid
					if(!password_valid)
						frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));

					setAppUser(certification.getAppUser());

					frame.Update_ApplicationUser(getAppUser());

					ReloadMainFrame(frame);

				}

				Timer timer = new Timer();
				timer.scheduleAtFixedRate(new TimerTask()
				{
					@Override
					public void run() {
						Heartbeat(frame);

					}
				}, 0, 1000);


			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	//Getter and setter
	public static User getAppUser() {
		return appUser;
	}

	public static void setAppUser(User AppUser) {
		appUser = AppUser;
	}

	//Heartbeat functionalities: Heartbeat, check friend requests, check calls
	public static void Heartbeat(FrameUI mainframe)
	{
		if (appUser == null) {return;}

		//Heartbeat
		JsonObject heartbeatJSON = new Gson().fromJson(
				RequestFunc.HTTP_AUTH_GET_REQUEST("localhost:8083/heartbeat",
						resourceFunc.appUser.getId(),
						resourceFunc.appUser.getPasswort()
				), JsonObject.class);


		//Friend Requests
		if (resourceFunc.FriendRequestAccepted) {
			ReloadMainFrame(mainframe);
			resourceFunc.FriendRequestAccepted = false;
		}
		String friendRequests = resourceFunc.HTTP_REQUEST("localhost:8083/students/" +
				resourceFunc.appUser.getId() +"/offenefreunde",
				null, "GET");

		if(friendRequests != null && !friendRequests.isEmpty()
				&& !friendRequests.startsWith("null")
				&& !resourceFunc.FriendRequest_LockPopUp)
		{
			List<String> friends = new ArrayList<>();
			friends = resourceFunc.JSON_String_toList(friendRequests);

			Gson gson = new Gson();
			User caller = gson.fromJson(friends.get(0), User.class);

			Incomming_FriendRequest(mainframe, caller);

			//Enable popup lock
			resourceFunc.FriendRequest_LockPopUp = true;
		}
		resourceFunc.heartbeatJSON = heartbeatJSON;

		if (!resourceFunc.IncomingCall_LockPopUp) {

			if (Objects.equals(heartbeatJSON.get("state").toString(), "1")) {

				String roomsString = heartbeatJSON.get("rooms").toString();

				if (!Objects.equals(roomsString, "[]")) {
				Incomming_Call(mainframe, Arrays.asList(
						roomsString.replace("[", ""
						).replace("]", "").split(",")));
				}
			}
		}
	}

	//Centers given frame
	public static void centerWindow(JFrame frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
	
	//Opens registration form 
	public static void firstRegistration(final FrameUI mainFrame) {
		 final RegistrationFrame regF = new RegistrationFrame();
		centerWindow(regF);
		//Make FrameUI visible as soon as the registration process has ended
		regF.addWindowListener(new WindowAdapter()
				{
					@Override
					public void windowClosing(WindowEvent e)
					{
						//Valid information
						if(regF.getAppUser() != null)
						{
							//server has been notified
							Gson gson = new Gson();
							String userJSON = gson.toJson(regF.getAppUser(), User.class);
							certification.saveCertificate(userJSON);
							setAppUser(regF.getAppUser());

							//Reload main frame
							ReloadMainFrame(mainFrame);
						}
						//Window closed > "X" 
						else if(regF.getDispatch())
						{
							mainFrame.dispatchEvent(new WindowEvent(mainFrame, WindowEvent.WINDOW_CLOSING));
						}
						//Not every field filled
						else
						{
							firstRegistration(mainFrame);
							JOptionPane.showMessageDialog(null, "Please fill out the registration form!");
						}
					}
				});
	}

	//Call pop-up
	public static void Incomming_Call(FrameUI mainFrame, List<String> rooms) {

		for (String room : rooms) {

			String roomInfoString = RequestFunc.HTTP_AUTH_GET_WRAPPED("localhost:8083/name/room/" + room, resourceFunc.appUser);

			if (roomInfoString != null) {
				User caller = new User(null);

				String mat = "";
				String str2 = roomInfoString;
				List<String> nummern = new ArrayList<>();
				while(!str2.isEmpty())
				{
					if(str2.indexOf(",") != -1) {
						mat = str2.substring(
								0,
								str2.indexOf(",")
						);
						nummern.add(mat);

						str2 = str2.substring(
								str2.indexOf(",") + 1,
								str2.length()
						);
						mat = str2;

						if(str2.indexOf(",") == -1)
						{
							str2 = "";
						}
					}
					else
					{
						nummern.add(str2);
						str2 = "";

						mat = str2;
					}
				}

				String namesOfFriends = "";

				for (String matNo :  nummern) {
					if (matNo != null || matNo != ""|| matNo != " ") {
						String targetUrl = "localhost:8083/students/" + matNo;
					namesOfFriends += new Gson().fromJson(
							resourceFunc.HTTP_REQUEST(targetUrl, null, "GET"),
							User.class).getName(); }
				}

				caller.setSurname(room);
				caller.setName(namesOfFriends);
				PopUp popUp = new PopUp(caller, "call");
				centerWindow(popUp);
				resourceFunc.IncomingCall_LockPopUp = true;
			}
		}
	}

	public static void Incomming_FriendRequest(FrameUI mainFrame, User caller)
	{
		PopUp popUp = new PopUp(caller, "friendRequest");
		centerWindow(popUp);
	}

	//Reloads current main frame
	public static void ReloadMainFrame(FrameUI frame)
	{
		frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
		frame = new FrameUI();
		frame.setTitle("DHBWTalk");
		frame.setBounds(new Rectangle(900, 600));
		frame.setMinimumSize(new Dimension(600, 300));
		centerWindow(frame);
		frame.setVisible(true);
		frame.Update_ApplicationUser(getAppUser());
	}
}
