# DHBWTalkServer

DHBWTalk
Team Seastian Eisele, Irakli May und Dennis Zimmerer

Inhaltsverzeichnis
--Einführung in die GUI
--Einrichtung der Datenbank

--------- GUI
-Anmeldung- Nachdem Sie sich erfolgreich angemeldet haben wird ein "Zertifikat" erstellt, welches unter dem Dokumenten Ordner ,,dhbwtalk" zu finden ist ("C:\Users\USERNAME\Documents\dhbwtalk"). Zum Anlegen mehrerer Personen kann man diese ,,certificate.txt" Datei einfach, in z.B. ,,USERNAME-certificate.txt",umbenennen und kann sich erneut registrieren. Folglich kann man sich mit verschiedenen angelegten Personen einloggen, indem man sicherstellt, dass das Zertifikat der anzumeldenden Person stets als ,,certificate.txt" im angegebenen Pfad aufzufinden ist. Das ist sehr wichtig, da das Anwendungsprogramm die Userdaten des Zertifikates holt, das genau die Benamung ,,certificate.txt" hat!

-Run on startup- Um das Programm beim Systemstart direkt ausführen zu können kann der ,,Run-on--Startup" Button mit einem rennenden Strichmännchen betätigen werden. Daraufhin wird eine dem OS entsprechende Datei (z.B. .bat bei Windows) im Startup Directory des jeweiligen OS angelegt. Bei erneuter Betätigung wird diese wieder gelöscht und die "Run on startup" Funktionalität deaktiviert.

--------- Einrichtungsanleitung der Datenbank

Schritte zur Einrichtung:

1. XAMPP download und installieren: https://www.apachefriends.org/de/download.html

2. Apache und MySQL im XAMPP Control Panel starten

3. Im Browser( http://localhost/phpmyadmin/index.php?route=/server/databases&server=1 ) bei Datenbankname "dhbwserver" eintragen und 'anlegen' klicken

4. Nun oben im Reiter auf SQL klicken und die dhbwserver.sql einfach in den Browser ziehen

5. Seite refreshen - die Datenbank ist nun eingerichtet
