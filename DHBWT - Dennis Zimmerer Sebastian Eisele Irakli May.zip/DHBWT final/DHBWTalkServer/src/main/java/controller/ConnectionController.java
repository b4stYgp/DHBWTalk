package controller;

import org.springframework.web.bind.annotation.*;
import models.Connection;
import models.Room;

import java.util.*;

@RestController
class ConnectionController {

  List<Connection> listConnection = new ArrayList<Connection>(); // List of all active Connections
  List<Room> listRoom = new ArrayList<Room>(){{
    add(new Room("https://bbb.dhbw-heidenheim.de/?M=xzNW8jI0M2U3Mu862pnC", 0));
    add(new Room("https://bbb.dhbw-heidenheim.de/?M=eBtgjI0NDNlMushX31Zj", 1));
    add(new Room("https://bbb.dhbw-heidenheim.de/?M=MwIJjI0MmQwMgkoqcKIf", 2));}};
  // List of all Rooms. In order to add additional rooms add them to the List. The roomNo has to be equal to its index.
  // TODO future: automatically load all available URLs' from a config file and enumerate them. Creating 'listRooms' dynamically.

  ConnectionController() {
    Cleaner(10000, 10000);
    // Start the cleaner, responsible for the removal of timed-out connections from 'listConnection' and 'listRooms'.
    // TODO future: Create a config file allowing to set 'period' and 'durationToCardiacArrest'.
  }


  //Cleaner, check periodically all Connections and Rooms for timeouts and zombies and remove them.
  /**
   * Check periodically all connections for timeouts every 'period' milliseconds.
   * A connection counts as timed-out if the duration from its timestamp to 'new Date().getTime()' is larger than 'durationToCardiacArrest'.
   * Whenever a connection times-out it has to be removed from all rooms.
   * Furthermore, all pending users of rooms without active users are removed after a grace period of 'period' milliseconds.
   *
   * @param period  Integer defining the interval of checks in milliseconds.
   * @param durationToCardiacArrest  Integer defining the time a connection can live without a heartbeat in milliseconds.
   *
   */
  private void Cleaner(int period, int durationToCardiacArrest) {

    Timer timer = new Timer();
    timer.scheduleAtFixedRate(new TimerTask() {

      @Override
      public void run() {

        List<Connection> deadConnections = new ArrayList<Connection>();
        // All rooms have to be checked for all dead connections later.

        if (!listConnection.isEmpty()) {
          Iterator<Connection> connectionIterator = listConnection.iterator();

          /**
          * Removing items from a list will cause an Exception to be thrown.
          * @see <a href="https://docs.oracle.com/javase/7/docs/api/java/util/ConcurrentModificationException.html"</a>
          * Changes to some objects relevant to the iteration are forbidden.
          * Using iterator remove method is allowed.
          */

          while (connectionIterator.hasNext()) {
            Connection cnxn = connectionIterator.next();
            if (new Date().getTime() - cnxn.getTimestamp().getTime() >= durationToCardiacArrest) {
              // Check if connection is dead by comparing the time passed, since its last heartbeat to 'durationToCardiacArrest'.

              Logfile.write("User timed out: '" + cnxn + "'");
              System.out.println("User timed out: '" + cnxn + "'");
              // TODO create logging class.

              deadConnections.add(cnxn);
              connectionIterator.remove(); // Remove the dead connection.
            }
          }

          for (Room room : listRoom) {
            if (room.checkRoom(null)) { // If no active users in room remove all pending ones.
              for (Connection zombie_cnxn : room.pending) {
                System.out.println("Zombie User got removed: '" + zombie_cnxn);
                // TODO create logging class.
                zombie_cnxn.state = 0; // Set 'state' of removed pending connections to 'idle'.
                zombie_cnxn.rooms.remove((Integer) room.roomNo); // This is remove by object not remove by index!
              }
              room.pending = new ArrayList<Connection>();
            }
            for (Connection cnxn : deadConnections) {
              room.dropConn(cnxn);
              // Dead connections are dropped from their rooms after the rooms got cleaned.
              // Allowing the pending users to have a grace period until the next cleaning interval.
            }

          }
        }
      }
    }, 0, period);}

  /**
   * Refreshes the timestamp and state of the user accessing the url.
   * Additionally it handles the creation of new Connections.
   * Users are identified by a Basic encrypted 'token' and 'matrikelnummer', witch are both passes inside the header.
   *
   *
   * @param matrikelnummer  String used to identify connections and students.
   * @param token  String used to authorize access. Not used right now.
   * @return  The Connection object of the user with id 'matrikelnummer'.
   */
  // TODO future instead of keeping all tokens only in the database.
  //  Keep a in-memory copy of tokens belonging to logged in Connections.
  //  Allowing for easier and consistent logins.
  @GetMapping("/heartbeat")
  public Connection updateConnection(@RequestHeader("matrikelnummer") String matrikelnummer,
                                     @RequestHeader("authorization") String token) {


    Connection connection = getConnById(matrikelnummer);

    if (connection != null) {
      connection.setTimestamp();
      if (connection.getState() != 0) {
        checkPending(connection); // Update the state of this connection. (states: 0 <=> idle, 1 <=> has pending call, 2 <=> in active call)
      }
    }
    else {
      connection = new Connection(token, matrikelnummer); // Represents a user first logging in with an existing account.
      System.out.println("Connection established: " + connection); // TODO add registration and login to logfile
      listConnection.add(connection); // Add new connection to the list of all active connections.
    }
    return connection;
  }

  /**
   * Represents the connecting to / calling of an existing connection with a different 'matrikelnummer'.
   * Sets the state of the connection initializing the call to '2' and the state of the receiving connection to state '1'.
   * Additionally, assigns rooms to connections, by checking if there are either empty rooms or if the initializing connection already owns one.
   *
   * @param requestingUserId  The ID of the user initializing the call. Used to get the related connection.
   * @param token  String used to authorize access. Not used right now. Only used for first login.
   * @param acceptingUserId   The ID of the user receiving the call. Used to get the related connection.
   * @return  Room.urlString String to get access to the room reserved for this call.
   */
  // TODO future check token of requestingUserId instead of allowing the client
  //  to check its credentials only once per login by querying the database.
  @GetMapping("/call/{matrikelnummer}")
  public String callConnection(@RequestHeader("matrikelnummer") String requestingUserId,
                               @RequestHeader("authorization") String token,
                               @PathVariable("matrikelnummer") String acceptingUserId) {

    System.out.println(requestingUserId + " tried calling " + acceptingUserId); // TODO add initiated call to logfile

    Connection requestingConn = getConnById(requestingUserId);
    Connection acceptingConn = getConnById(acceptingUserId);

    if (requestingConn == null || acceptingConn == null)
    {requestingConn.message = "Call failed.\nRequested user is offline"; return null;}
    /* If a user has no related 'Connection' instance, the user is offline.
    * User could be non-existent. Resolved by not allowing users to log in without valid credentials. */
    if (requestingConn == acceptingConn)
    {requestingConn.message = "'How much can you know about yourself if you have never been in a fight?'"; return null;} // You cannot call yourself. Resolved clientside.
    if (acceptingConn.state == 2)
    {requestingConn.message = "User is busy."; return null;}
    /* State '2' indicates that a user is already in a call.
    * While users already in calls cannot be called, users with pending calls will add the requesting room to their 'rooms'.
    * Client will iterate through pending calls allowing the accumulation of multiple pending calls.*/

    switch (((requestingConn.getState() == 0) ? 0 : 1) + "" + ((requestingConn.getState() == 0) ? 0 : 1)) {
      // Concatenation of the states of both receiving and initiating client improves the overview of possible call states.
      case "01", "11", "00" -> {
        // both clients are not in active calls
        Room emptyRoom = listRoom.stream()
                .filter(room -> room.checkRoom(null).equals(true))
                .findAny()
                .orElse(null);
        // Find an empty room to assign the initiating connection to while waiting for the requested one.

        if (emptyRoom == null) {
          requestingConn.message = "No free Rooms available."; return null;
        }

        emptyRoom.addActive(requestingConn);
        emptyRoom.addPending(acceptingConn);
        return emptyRoom.urlString;

      }
      case "20", "21" -> { // Initiating client already owns a room.
        Room activeRoom = listRoom.get(requestingConn.getRoom());
        activeRoom.addPending(acceptingConn);
        return activeRoom.urlString;
      }
    }
    return null;
  }

  /**
   * Represents the connection relating to client with ID 'matrikelnummer' leaving all rooms.
   *
   * @param matrikelnummer  The ID of the client leaving.
   * @param token  String used to authorize access. Not used right now. Only used for first login.
   */
  @GetMapping("/leave")
  public void leaveRoom(@RequestHeader("matrikelnummer") String matrikelnummer,
                        @RequestHeader("authorization") String token) {
    Connection leavingConn = getConnById(matrikelnummer);
    listRoom.get(leavingConn.room).dropConn(leavingConn);
    leavingConn.rooms.remove((Integer)leavingConn.room); // Remove by Object not by index!
    leavingConn.state = 0;
    leavingConn.room = -1; // -1 indicates the lack of room ownership.
    leavingConn.url = "";
    System.out.println("User left call: '" + leavingConn + "'"); //TODO add to logfile.
  }

  /**
   * Represents the connection relating to client with ID 'matrikelnummer' leaving a specific room.
   *
   * @param matrikelnummer  The ID of the client leaving.
   * @param token  String used to authorize access. Not used right now. Only used for first login.
   * @param roomNo The room number the client is leaving.
   */
  @GetMapping("/leave/{roomNo}")
  public void leaveRoom(@RequestHeader("matrikelnummer") String matrikelnummer,
                        @RequestHeader("authorization") String token,
                        @PathVariable("roomNo") int roomNo) {

    Connection leavingConn = getConnById(matrikelnummer);
    listRoom.get(roomNo).dropConn(leavingConn); // Remove client from Room.
    try {
      leavingConn.rooms.remove(roomNo); // Remove room from client room list.
    } catch (Exception e) {};
    if (leavingConn.rooms.isEmpty()) {leavingConn.state = 0; return;} // If rooms is empty there are no active and pending rooms. This means client is idle again.
    System.out.println("User ignored call from room: '" + listRoom.get(roomNo) + "'"); //TODO add to logfile
    // A client leaving a pending room is the client ignoring a call

  }

  /**
   * Returns information regarding the room the client wants to know more about.
   * Only accessible if the client is pending in this room.
   *
   * @param matrikelnummer  The ID of the client.
   * @param token  String used to authorize access. Not used right now. Only used for first login.
   * @param roomNo The room number the client is investigating.
   * @return A string containing all relevant room information.
   */
  // TODO add a active room check and let the heartbeat handle the check -> difficulty heartbeat might not be on time
  //  to periodically generate a list of active and pending users in a room. Display those clientside.
  @GetMapping("/room/{roomNo}")
  public String checkRoom(@RequestHeader("matrikelnummer") String matrikelnummer,
                          @RequestHeader("authorization") String token,
                          @PathVariable int roomNo) {
    Connection checkingConn = getConnById(matrikelnummer);
    Room room = listRoom.get(roomNo);
    if (room.pending.contains(checkingConn)) {
      return room.toString();
    }
    return null;
  }

  @GetMapping("/name/room/{roomNo}") //HOT FIX
  public String checkRoomGetName(@RequestHeader("matrikelnummer") String matrikelnummer,
                          @RequestHeader("authorization") String token,
                          @PathVariable int roomNo) {
    Connection checkingConn = getConnById(matrikelnummer);
    Room room = listRoom.get(roomNo);
    if (room.pending.contains(checkingConn)) {
      String nameList = "";
      for (Connection nameConn: room.active) {
        nameList += nameConn.getUsername() + ",";
      }
      System.out.println(nameList);
      return nameList;
    }
    return null;
  }

  /**
   * Represents a client joining a room by changing its state to '2',
   * setting its room and its url to the room the client now belongs to.
   *
   * @param requestingUserId  The ID of the client.
   * @param token  String used to authorize access. Not used right now. Only used for first login.
   * @param roomNo The room number the client is joining.
   * @return A string to the url of the room.
   */
  // TODO add a active room check and let the heartbeat handle the check -> difficulty heartbeat might not be on time
  //  to periodically generate a list of active and pending users in a room. Display those clientside.
  @GetMapping("/join/{roomNo}")
  public String joinRoom(@RequestHeader("matrikelnummer") String requestingUserId,
                       @RequestHeader("authorization") String token,
                       @PathVariable("roomNo") int roomNo) {


    System.out.println(requestingUserId + " joins roomNo " + roomNo);

    Connection joiningConn = listConnection.stream()
            .filter(cnxn -> requestingUserId.equals(cnxn.getUsername()))
            .findAny()
            .orElse(null);

    Room room = listRoom.get(roomNo);
    if (!room.checkRoom(joiningConn))  {joiningConn.message = "This room is private."; return null;}
    room.addActive(joiningConn);
    joiningConn.url = room.urlString;
    return room.urlString; // TODO change to void by using heartbeat information clientside
  }

  /* Used for testing. Displays all relevant information.*/
   @GetMapping("/info")
  public String getInfo()
  {
    StringBuilder infoString = new StringBuilder();
    for(Room room:listRoom) {
      infoString.append(room).append("\n");
    }
    for(Connection cnxn:listConnection) {
      infoString.append(cnxn).append("\n");
    }
    System.out.println("/info\n" + infoString);
    return infoString.toString();
  }

  /**
   * Find connection by ID by using '.stream()' returning either a 'Connection' or 'null' if none were found.
   *
   * @param matrikelnummer  String used to identify connections and students .
   * @return  Connection object with ID matrikelnummer.
   */
  // TODO check if API handles duplicate matrikelnummer exception.
  public Connection getConnById(String matrikelnummer) {
    return listConnection.stream()
            .filter(cnxn -> matrikelnummer.equals(cnxn.getUsername()))
            .findAny()
            .orElse(null);
  }


  /**
   * Check connection for pending invites to rooms.
   *
   * @param checkingConn The connection that wants to check for pending invites to rooms.
   */
  // TODO future Can be improved to handle pending friend requests as well.
  public void checkPending(Connection checkingConn) {
    for (Room room : listRoom) {
      if (room.checkRoom(checkingConn) && !checkingConn.rooms.contains(room.roomNo))
      // If checkingConn is either active or pending for room add to its own rooms.
      {
        checkingConn.rooms.add(room.roomNo);
      }
    }
  }

}



